package com.test.refactoring.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
/**
 * 
 * @author Juanan
 * @version 1.0
 *
 */

public class Utils {

	public static String hora_actual() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("hh:MM:ss");
		// System.out.println("HH:MM:SS-> "+dtf.format(LocalDateTime.now()));

		return dtf.format(LocalDateTime.now());
	}
	/**
	 * 
	 * @return String
	 */

	public static String fecha_actual() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("YYYY/mm/dd");
		// System.out.println("YYYY/MM/DD-> "+dtf.format(LocalDateTime.now()));

		return dtf.format(LocalDateTime.now());
	}
	/**
	 * 
	 * @param dias
	 * @return String
	 */

	public static float calcularPrecioAlquiler(Integer dias) {
		float result = 0;
		// El coste de un d�a de alquiler son 50� + 21% de IVA
		result = dias * 50 * 1.21f;
		return result;
	}
	/**
	 * 
	 * @param meses
	 * @return float
	 */

	public static float calcularPrecioRenting(Integer meses) {
		// El coste de un mes de renting son 750� + 21% IVA
		return meses * 750 * 1.21f;
	}

}
