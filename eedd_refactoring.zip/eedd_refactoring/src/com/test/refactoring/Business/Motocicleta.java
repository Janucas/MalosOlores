package com.test.refactoring.Business;

/**
 * 
 * @author Juanan
 * @version 1.0
 *
 */

public class Motocicleta {

	private String matricula;
	private String color;
	private String combustible;
	private Integer cilindrada;
	private String nombreConductor;
	private String dniConductor;
	/**
	 * Declaro las variables que va a tener mi clase
	 * @param matricula
	 * @param color
	 * @param combustible
	 * @param cilindrada
	 * @param nombre_conductor
	 * @param dniConductor
	 */

	public Motocicleta(String matricula, String color, String combustible, Integer cilindrada, String nombre_conductor,
			String dniConductor) {
		super();
		this.matricula = matricula;
		this.color = color;
		this.combustible = combustible;
		this.cilindrada = cilindrada;
		this.nombreConductor = nombre_conductor;
		this.dniConductor = dniConductor;
	}


	public String getMatricula() {
		return matricula;
	}
	/**
	 * 
	 * @param matricula
	 */

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	/**
	 * 
	 * @return void
	 */

	public String getColor() {
		return color;
	}
	/**
	 * 
	 * @param color
	 */

	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * 
	 * @return void
	 */

	public String getCombustible() {
		return combustible;
	}
	/**
	 * 
	 * @param combustible
	 */

	public void setCombustible(String combustible) {
		this.combustible = combustible;
	}
	/**
	 * 
	 * @return void
	 */

	public Integer getCilindrada() {
		return cilindrada;
	}
	/**
	 * 
	 * @param cilindrada
	 */

	public void setCilindrada(Integer cilindrada) {
		this.cilindrada = cilindrada;
	}
	/**
	 * 
	 * @return void
	 */

	public String getNombre_conductor() {
		return nombreConductor;
	}
	/**
	 * 
	 * @param nombre_conductor
	 */

	public void setNombre_conductor(String nombre_conductor) {
		this.nombreConductor = nombre_conductor;
	}
	/**
	 * 
	 * @return void
	 */

	public String getDniConductor() {
		return dniConductor;
	}
	/**
	 * 
	 * @param dniConductor
	 */

	public void setDniConductor(String dniConductor) {
		this.dniConductor = dniConductor;
	}
	/**
	 * 
	 * @param velocidad
	 */

	public void acelerar(Integer velocidad) {
		// TO DO
	}

	public void detener() {
		// TO DO
	}

	@Override
	public String toString() {
		return "motocicleta [matricula=" + matricula + ", color=" + color + ", combustible=" + combustible
				+ ", cilindrada=" + cilindrada + ", nombre_conductor=" + nombreConductor + ", dniConductor="
				+ dniConductor + "]";
	}

}
