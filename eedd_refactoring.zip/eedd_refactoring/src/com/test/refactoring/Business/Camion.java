package com.test.refactoring.Business;

/**
 * 
 * @author Juanan
 * @version 1.0
 *
 */

public class Camion {

	private String matricula;
	private String color;
	private String combustible;
	private String tipoCarnet;
	private String nombreConductor;
	private String dniConductor;

	public Camion() {
		super();
	}
	/**
	 * Declaro las variables que va a tener mi clase 
	 * @param matricula
	 * @param color
	 * @param combustible
	 * @param tipoCarnet
	 * @param nombre_conductor
	 * @param dniConductor
	 */

	/**
	 * 
	 * @param matricula
	 * @param color
	 * @param combustible
	 * @param tipoCarnet
	 * @param nombre_conductor
	 * @param dniConductor
	 */
	public Camion(String matricula, String color, String combustible, String tipoCarnet, String nombre_conductor,
			String dniConductor) {
		super();
		this.matricula = matricula;
		this.color = color;
		this.combustible = combustible;
		this.tipoCarnet = tipoCarnet;
		this.nombreConductor = nombre_conductor;
		this.dniConductor = dniConductor;
	}
	/**
	 * 
	 * @return String
	 */

	public String getMatricula() {
		return matricula;
	}
	/**
	 * 
	 * @param matricula
	 */

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	/**
	 * 
	 * @return String
	 */

	public String getColor() {
		return color;
	}
	/**
	 * 
	 * @param color
	 */

	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * 
	 * @return void
	 */

	public String getCombustible() {
		return combustible;
	}
	/**
	 * 
	 * @param combustible
	 */

	public void setCombustible(String combustible) {
		this.combustible = combustible;
	}
	/**
	 * 
	 * @return void
	 */

	public String getTipoCarnet() {
		return tipoCarnet;
	}
	/**
	 * 
	 * @param tipoCarnet
	 */

	public void setTipoCarnet(String tipoCarnet) {
		this.tipoCarnet = tipoCarnet;
	}
	/**
	 * 
	 * @return void
	 */

	public String getNombreConductor() {
		return nombreConductor;
	}
	/**
	 * 
	 * @param nombre_conductor
	 */

	public void setNombreConductor(String nombre_conductor) {
		this.nombreConductor = nombre_conductor;
	}
	/**
	 * 
	 * @return void
	 */

	public String getDniConductor() {
		return dniConductor;
	}
	/**
	 * 
	 * @param dniConductor
	 */

	public void setDniConductor(String dniConductor) {
		this.dniConductor = dniConductor;
	}
	/**
	 * 
	 * @param velocidad
	 * @return void
	 */

	public void acelerar(Integer velocidad) {
		System.out.println("La aceleraci�n del cami�n se realizar� progresivamente para conservar sus neum�ticos");

		// TO DO
		// Incluir l�gica de movimiento
	}

	public void detener() {
		System.out
				.println("CUIDADO!! La detenci�n de un veh�culo de gran tama�o puede ocasionar accidentes de tr�fico");
	}

	@Override
	public String toString() {
		return "Camion [matricula=" + matricula + ", color=" + color + ", combustible=" + combustible + ", tipoCarnet="
				+ tipoCarnet + ", nombre_conductor=" + nombreConductor + ", dniConductor=" + dniConductor + "]";
	}

}
