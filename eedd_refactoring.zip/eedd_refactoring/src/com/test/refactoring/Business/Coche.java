package com.test.refactoring.Business;
/**
 * 
 * @author Juanan
 *@version 1.0
 *
 */

public class Coche {

	private String matricula;
	private String color;
	private String combustible;
	private Integer numPlazas;
	private String nombreConductor;
	private String dniConductor;

	public Coche() {
		super();
	}
	/**
	 * Declaro las variables que va a tener mi clase
	 * @param matricula
	 * @param color
	 * @param combustible
	 * @param numPlazas
	 * @param nombre_conductor
	 * @param dniConductor
	 */

	public Coche(String matricula, String color, String combustible, Integer numPlazas, String nombre_conductor,
			String dniConductor) {
		super();
		this.matricula = matricula;
		this.color = color;
		this.combustible = combustible;
		this.numPlazas = numPlazas;
		this.nombreConductor = nombre_conductor;
		this.dniConductor = dniConductor;
	}

	public String getMatricula() {
		return matricula;
	}
	/**
	 * 
	 * @param matricula
	 */

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	/**
	 * 
	 * @return void
	 */

	public String getColor() {
		return color;
	}
	/**
	 * 
	 * @param color
	 */

	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * 
	 * @return void
	 */

	public String getCombustible() {
		return combustible;
	}
	/**
	 * 
	 * @param combustible
	 */

	public void setCombustible(String combustible) {
		this.combustible = combustible;
	}
	/**
	 * 
	 * @return void
	 */

	public Integer getNumPlazas() {
		return numPlazas;
	}
	/**
	 * 
	 * @param numPlazas
	 */

	public void setNumPlazas(Integer numPlazas) {
		this.numPlazas = numPlazas;
	}
	/**
	 * 
	 * @return void
	 */

	public String getNombreConductor() {
		return nombreConductor;
	}
	/**
	 * 
	 * @param nombre_conductor
	 */

	public void setNombreConductor(String nombre_conductor) {
		this.nombreConductor = nombre_conductor;
	}
	/**
	 * 
	 * @return void
	 */

	public String getDniConductor() {
		return dniConductor;
	}
	/**
	 * 
	 * @param dniConductor
	 */

	public void setDniConductor(String dniConductor) {
		this.dniConductor = dniConductor;
	}
	/**
	 * 
	 * @param velocidad
	 */

	public void acelerar(Integer velocidad) {
		if (velocidad > 0 && velocidad < 120) {
			System.out.println("El coche est� acelerando y llegar� la velocidad de " + velocidad.intValue() + " km/h");
		} else {
			System.out.println("La velocidad indicada no est� permitida en un coche seg�n la DGT");
		}
	}

	public void detener() {
		System.out.println("El coche se detendr� en breve, aseg�rese de buscar un lugar adecuado para estacionar");
	}

	@Override
	public String toString() {
		return "Coche [matricula=" + matricula + ", color=" + color + ", combustible=" + combustible + ", numPlazas="
				+ numPlazas + ", nombre_conductor=" + nombreConductor + ", dniConductor=" + dniConductor + "]";
	}

}
